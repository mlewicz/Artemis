import requests
import json
import logging
from ruxit.api.base_plugin import BasePlugin
from ruxit.api.snapshot import pgi_name
class QueueExecute(BasePlugin):
    def query(self, **kwargs):
        #try:    
        self.metric_type = self.config["metric_type"].split(';')
        self.queue_name = self.config["queue_name"].split(';')
        self.process = self.config["process"]
        dict = {
        "artemis_message_count": "eventbus_message_count",
        "artemis_messages_acknowledged": "eventbus_messages_acknowledged",
        "artemis_consumer_count": "eventbus_consumer_count",
        "artemis_messages_killed": "eventbus_messages_killed",
        "artemis_messages_expired": "eventbus_messages_expired"}
        
        #broker = config["broker"]#optional
        #adress = config["adress"]#optional 
        self.url = self.config["url"]
        pgi = self.find_single_process_group(pgi_name(self.process))
        pgi_id = pgi.group_instance_id
        with requests.Session() as session_requests:
            self.result = session_requests.get(self.url,timeout=5)
            for x in self.result.text.split('\n'):
                if x.startswith('#') or 'queue="' not in x:
                    continue
                self.source_metric_type=x[:x.find('{')]
                self.source_queue_name=x[x.find('queue="')+7:x[x.find('queue="'):].find('",')+x.find('queue="')]
                self.values=x.split(' ')[1]
                if self.source_metric_type in self.metric_type and self.source_queue_name in self.queue_name:
                    if self.source_metric_type in dict:
                        self.source_metric_type=dict[self.source_metric_type]#słownik
                    self.results_builder.absolute(key="MQ_Artemis_"+self.source_metric_type, value=float(self.values), dimensions={'queue_name': self.source_queue_name}, entity_id=pgi_id)
                    #print(x,source_metric_type,source_queue_name,value)
                    #input()
        #except Exception as e:
        #    pass
#metric_type="artemis_message_count".split(';')
#queue_name ="suspectedDocumentNotificationQueueSFP".split(';')
#
#url='http://localhost:8161/metrics/'
#with requests.Session() as session_requests:
#    result = session_requests.get(url)
#    for x in result.text.split('\n'):
#        if x.startswith('#') or 'queue="' not in x:
#            continue
#        source_metric_type=x[:x.find('{')]
#        source_queue_name=x[x.find('queue="')+7:x[x.find('queue="'):].find('",')+x.find('queue="')]
#        value=x.split(' ')[1]
#        if source_metric_type in metric_type and source_queue_name in queue_name:
#            print(x,source_metric_type,source_queue_name,value)
#            input()
#    print(metric_type,queue_name)